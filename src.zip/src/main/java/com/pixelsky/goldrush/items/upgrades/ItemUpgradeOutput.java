package com.pixelsky.goldrush.items.upgrades;

public class ItemUpgradeOutput {
    //将原本物品浮空改为自动搜集.
}
