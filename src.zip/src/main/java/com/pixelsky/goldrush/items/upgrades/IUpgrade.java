package com.pixelsky.goldrush.items.upgrades;

public interface IUpgrade {
}
