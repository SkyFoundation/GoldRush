package com.pixelsky.goldrush.items.upgrades;

public class ItemUpgradeSpeed {
}
