package com.pixelsky.goldrush.gui;

public class GuiMachineDetector {
}
