package com.pixelsky.goldrush.entity;

public interface IUpgradeHandler {
    void handleUpgrade();
}
