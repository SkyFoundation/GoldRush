
package com.pixelsky.goldrush.init;

public class ModCapabilitys {

	public ModCapabilitys() {
		register();
	}
	
	public void register() {
//		CapabilityManager.INSTANCE.register(IHadItems.class, new HadItemsStorage(), HadItems.class);

	}
	
}
