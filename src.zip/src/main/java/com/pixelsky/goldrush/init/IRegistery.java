package com.pixelsky.goldrush.init;

public interface IRegistery {
   // void init();
    void register();
}
