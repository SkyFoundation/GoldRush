package com.pixelsky.goldrush.blocks.machine;

public interface IMachine {
  void   handelUpgrade();
}
