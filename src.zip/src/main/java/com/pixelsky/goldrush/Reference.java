package com.pixelsky.goldrush;

public class Reference
{
	public static final String MODID = "goldrush";
	public static final String NAME = "Gold Rush";
	public static final String VERSION = "1.2.0";
	public static final String CLIENTPROXY = "com.pixelsky.goldrush.proxy.ClientProxy";
	public static final String COMMONPROXY = "com.pixelsky.goldrush.proxy.CommonProxy";
	
}
