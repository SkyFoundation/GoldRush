package com.pixelsky.goldrush.capability.blockmelt;

public class CapabilityMelt {
}
