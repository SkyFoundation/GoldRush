package com.pixelsky.goldrush.capability.blockdetecte;
//发现方块的能力
public class CapabilityBlockDetect {
}
