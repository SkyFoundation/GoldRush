package com.pixelsky.goldrush.capability.evoluate;

public class CapabilityEvolutate {
}
