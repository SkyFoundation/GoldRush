package com.pixelsky.goldrush.capability.veinmine;

public class CapabilityVeinMine {
}
