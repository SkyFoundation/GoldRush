package com.pixelsky.goldrush.capability.blockdestroy;
//方块破坏器物品的能力
public class CapabilityBlockDestroy {
}
