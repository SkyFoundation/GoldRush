package com.pixelsky.goldrush;

public class Debug {
    public static void info(String s){
        System.out.println("DEBUG: "+s);
    }
}
